import * as core from '@actions/core';
import * as github from '@actions/github';
import fetch from 'node-fetch';

async function run() {
  try {
    const webhookUrl = core.getInput('webhook-url');
    const message = core.getInput('message');
    const channel = core.getInput('channel');
    const event = core.getInput('event') || github.context.eventName;

    if (!webhookUrl || !message || !channel) {
      throw new Error('Missing required inputs');
    }

    const payload = {
      text: message,
      channel: channel,
    };

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Slack notification failed: ${response.statusText}`);
    }

    core.info('Slack notification sent successfully');
  } catch (error) {
    if (error instanceof Error) {
      core.setFailed(error.message);
    } else {
      core.setFailed('An unknown error occurred');
    }
  }
}

run();
