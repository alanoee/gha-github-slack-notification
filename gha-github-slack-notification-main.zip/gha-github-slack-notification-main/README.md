# Slack Notification Action

This action sends notifications to Slack based on GitHub events.

## Inputs

### `webhook-url`

**Required** The Slack Incoming Webhook URL.

### `message`

**Optional** Custom message to send to Slack. If not provided, a default message based on the GitHub event will be sent.

### `channel`

**Required** The Slack channel to send the message to. This should be in the format `#channel-name`.

### `event`

**Required** The GitHub event that triggers the notification (e.g., `push`, `pull_request`, `issues`, `release`).

## Example usage

```yaml
- uses: SallingGroup-DevOps/gha-github-slack-notification@v1.0.1
  with:
    webhook-url: ${{ secrets.SLACK_WEBHOOK_URL }}
    message: 'Custom message'
    channel: '#your-channel'
    event: 'push'  # Specify the GitHub event to trigger the notification
